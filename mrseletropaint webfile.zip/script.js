const menuToggle = document.querySelector('.menu-toggle');
const siteNav = document.querySelector('.site-nav');

menuToggle?.addEventListener('click', () => {
  const isOpen = siteNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});

document.querySelectorAll('.site-nav a').forEach((link) => {
  link.addEventListener('click', () => {
    siteNav.classList.remove('open');
    menuToggle?.setAttribute('aria-expanded', 'false');
  });
});

document.getElementById('year').textContent = new Date().getFullYear();

const bookingForm = document.getElementById('booking-form');
const formNote = document.getElementById('form-note');

bookingForm?.addEventListener('submit', (event) => {
  event.preventDefault();
  const data = new FormData(bookingForm);
  const name = String(data.get('name') || '').trim();
  const service = String(data.get('service') || '').trim();
  const details = String(data.get('message') || '').trim();
  const body = `Hello MRS Electropaint, my name is ${name}. I would like help with ${service.toLowerCase()}.${details ? ` Here are a few details: ${details}` : ''}`;
  const whatsappUrl = `https://wa.me/60167030840?text=${encodeURIComponent(body)}`;
  formNote.textContent = 'Opening WhatsApp with your enquiry…';
  window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
});

const ratingInputs = document.querySelectorAll('input[name="customer-rating"]');
const ratingScore = document.getElementById('rating-score');
const ratingDisplay = document.getElementById('rating-display');
const ratingCount = document.getElementById('rating-count');
const ratingNote = document.getElementById('rating-note');
const ratingStorageKey = 'mrs-electropaint-ratings';

const readRatings = () => {
  try {
    const stored = JSON.parse(localStorage.getItem(ratingStorageKey) || '[]');
    return Array.isArray(stored) ? stored.filter((value) => Number.isInteger(value) && value >= 1 && value <= 5) : [];
  } catch {
    return [];
  }
};

const renderRatings = (ratings) => {
  const count = ratings.length;
  const average = count ? ratings.reduce((total, value) => total + value, 0) / count : 0;
  const rounded = Math.round(average);
  ratingScore.textContent = count ? average.toFixed(1) : '—';
  ratingDisplay.textContent = count ? `${'★'.repeat(rounded)}${'☆'.repeat(5 - rounded)}` : '☆ ☆ ☆ ☆ ☆';
  ratingDisplay.setAttribute('aria-label', count ? `${average.toFixed(1)} out of 5 stars` : 'No ratings yet');
  ratingCount.textContent = `${count} customer rating${count === 1 ? '' : 's'}`;
};

let ratings = readRatings();
renderRatings(ratings);

ratingInputs.forEach((input) => {
  input.addEventListener('change', () => {
    ratings = [...ratings, Number(input.value)];
    localStorage.setItem(ratingStorageKey, JSON.stringify(ratings));
    renderRatings(ratings);
    ratingNote.textContent = 'Thank you — your rating has been recorded.';
  });
});
