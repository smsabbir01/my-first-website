# MRS Electropaint — Implementation & Design Plan

## Product scope
A single-page portfolio website for MRS Electropaint: house wiring, installation of lights/fans/AC, and interior/exterior painting according to customer design. The site must show individual installation prices, make booking easy through WhatsApp or email, and end with a footer containing WhatsApp-enabled phone, email, and location.

The site also includes a “Customer’s satisfaction” section with a five-star rating option, a live average score, and a customer rating count that starts at zero and persists ratings in the visitor’s browser.

## Implementation approach
- Use a lightweight static web app with no server or database: HTML, CSS, and vanilla JavaScript served on port 3000.
- Use semantic sections and anchor navigation: hero, services, pricing, work/painting, booking, footer.
- Use direct `wa.me` and `mailto:` actions for booking and contact; no form data is persisted.
- Use inline SVG/CSS motifs rather than external image dependencies so the page stays fast, portable, and visually coherent.
- Include `public/manus-routes.json` with the single `/` route.
- Include responsive behavior for mobile, accessible focus states, keyboard-friendly navigation, reduced-motion support, and visible status feedback when the booking form is submitted.

## Design direction
### Design movement
**Industrial editorial / dark Swiss utility**: an austere, crafted interface that feels like a workshop wall, but with enough warmth from wood tones to feel residential and trusted.

### Core principles
1. **Clarity before decoration** — prices, services, and contact actions are instantly scannable.
2. **Crafted utility** — rules, labels, and measured spacing echo electrical plans and workshop markings.
3. **Warm precision** — concrete-gray surfaces and white type are softened by a honey-wood accent.
4. **Human-scale trust** — plainspoken copy, real service categories, and no inflated claims.

### Color philosophy
Near-black graphite is the canvas for contrast and confidence. Concrete gray supplies structure and a tactile built-environment reference. Chalk white keeps information calm and legible. Honey wood is the ownable brand note: warm enough to signal interior care, distinctive against the dark field, and reserved for action/price moments.

### Layout paradigm
A left-anchored editorial column with an offset hero composition and wide horizontal service bands. Avoid a generic centered marketing grid: headings sit in a narrow rail while content expands into asymmetric panels. Pricing uses a long-form list with numbered rows, like a workshop estimate.

### Signature elements
- A compact square “M” mark built from an electrical bolt/line motif.
- A thin honey rule and oversized section numerals that behave like blueprint annotations.
- Service cards with concrete-gray texture blocks and small monospace metadata labels.

### Interaction philosophy
Interactions feel like switches: decisive, tactile, and obvious. Buttons have strong hover/active states, booking choices are direct (WhatsApp/email), and the email form turns intent into a pre-filled message without trapping the visitor in a complex workflow.

### Animation
Use only short, purposeful transitions: hero lines reveal with a subtle stagger, cards lift 4px on hover, and the mobile menu opens with a compact fade/slide. Respect `prefers-reduced-motion` and remove all non-essential motion when requested.

### Typography system
Use `Manrope` for headings and body (geometric, clear, contemporary) with `IBM Plex Mono` for labels, prices, and technical metadata. H1 is clamp-sized and tight; section headings are uppercase with generous tracking; body copy is compact with 1.6 line-height.

### Brand essence
**Positioning:** The practical electrical and painting partner for homes that want clean installations and considered finishes in one call.
**Personality:** precise, warm, dependable.

### Brand voice
Direct, reassuring, and specific. No generic “welcome” language.
- “Clean power. Considered finish.”
- “Tell us what your home needs. We’ll bring the right tools.”

### Wordmark & logo
A compact square mark with an angled bolt cut through an “M” construction, paired with a small uppercase wordmark. The mark appears in the header and favicon-style badge; it is drawn in CSS/SVG so it remains crisp at any size.

### Signature brand color
**Workshop Honey** `#D79A5B`, used for prices, focus rings, rules, and primary CTA emphasis.

## Project structure
- `index.html` — semantic page structure and content.
- `styles.css` — design tokens, layout, responsive breakpoints, components, motion.
- `script.js` — mobile navigation, year, and WhatsApp/email booking behavior.
- `public/manus-routes.json` — route manifest required by the Webdev runtime.
- `app.config.ts` — project logo metadata when a durable HTTPS logo URL is available.
- `plan.md` / `TODO.md` — approved scope and delivery outcomes.

## Serving/build
The app is a no-build static site. A small Node server serves the project root on `0.0.0.0:3000`. The managed project remains serverless in product terms; this server is only the Preview runtime.
